package com.example.dllo.lexuebdemo.find.findview;

import com.example.dllo.lexuebdemo.R;
import com.example.dllo.lexuebdemo.base.BaseActivity;

/**
 * Created by dllo on 17/3/10.
 * 王宇琦
 */

public class FindDetilCafeActivity extends BaseActivity{

    @Override
    protected int getLayout() {
        return R.layout.activity_find_cafe;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initListener() {

    }

}
