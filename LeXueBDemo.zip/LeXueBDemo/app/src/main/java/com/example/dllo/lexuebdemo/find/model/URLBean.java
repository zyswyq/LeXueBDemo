package com.example.dllo.lexuebdemo.find.model;

/**
 * Created by dllo on 17/3/10.
 * 王宇琦
 */

public class URLBean {

    public static String FINDVIDEO1="http://api.lexue.com/live/list?page_size=10&page=";
    public static String FINDVIDEO2="&subject_id=";
    public static String FINDVIDEO3="&status=";
}
