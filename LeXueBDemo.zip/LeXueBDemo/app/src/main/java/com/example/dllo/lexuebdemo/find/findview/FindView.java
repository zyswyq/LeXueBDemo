package com.example.dllo.lexuebdemo.find.findview;

import android.content.Intent;

/**
 * Created by dllo on 17/3/9.
 * 王宇琦
 */

public interface FindView {
    void  setAdapter();
    void goActivity(Intent intent);
}
