package com.example.dllo.lexuebdemo.main.view;

import android.support.v4.app.Fragment;

/**
 * Created by dllo on 17/3/9.
 * 王宇琦
 */

public interface MainView {

    void selectFragment(int i);

}
