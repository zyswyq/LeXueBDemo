package com.example.dllo.lexuebdemo.teacher;

/*
    by Mr.L
    data 2017-03-09
    desc 描述
*/
public interface TeacherSubjectView {
    void setAdapter();
    void setRecyclerView();
}
