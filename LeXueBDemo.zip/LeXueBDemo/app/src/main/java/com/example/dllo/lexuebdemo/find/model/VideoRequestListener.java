package com.example.dllo.lexuebdemo.find.model;

/**
 * Created by dllo on 17/3/10.
 */

public interface VideoRequestListener {
    void onSuccess(FindVideoBean bean);
    void onError();
}
